from flask import Flask, render_template, request
import jsonify
import requests
import pickle
import numpy as np
import sklearn
from sklearn.preprocessing import StandardScaler
app = Flask(__name__)
model = pickle.load(open('random_forest_regression_model.pkl', 'rb'))
@app.route('/',methods=['GET'])
def Home():
    return render_template('index.html')


standard_to = StandardScaler()
@app.route("/predict", methods=['POST'])
def predict():
    if request.method == 'POST':
        year = int(request.form['year'])
        
        km_driven=float(request.form['km_driven'])
        
        AvgMileage=float(request.form['AvgMileage'])
        
        EngineCC=int(request.form['EngineCC'])
        
        MaxPower=float(request.form['Maxpower'])
        
        Fuel_Petrol=request.form['Fuel_Petrol']
        if(Fuel_Petrol=='Petrol'):
                Fuel_CNG=0
                Fuel_Diesel=0
                Fuel_LPG=0
                Fuel_Petrol=1
        elif(Fuel_Petrol=='Diesel'):
                Fuel_CNG=0
                Fuel_Diesel=1
                Fuel_LPG=0
                Fuel_Petrol=0
        elif(Fuel_Petrol=='CNG'):
                Fuel_CNG=1
                Fuel_Diesel=0
                Fuel_LPG=0
                Fuel_Petrol=0
        else:
                Fuel_CNG=0
                Fuel_Diesel=0
                Fuel_LPG=1
                Fuel_Petrol=0   
        
        SellerType_Dealer=request.form['SellerType_Dealer']
        if(SellerType_Dealer=='Dealer'):
                SellerType_Dealer=1
                SellerType_Individual=0
                SellerType_TrustmarkDealer=0
        elif(SellerType_Dealer=='Individual'):
                SellerType_Dealer=0
                SellerType_Individual=1
                SellerType_TrustmarkDealer=0
        else:
                 SellerType_Dealer=0
                 SellerType_Individual=0
                 SellerType_TrustmarkDealer=1

        Transmission_Manual=request.form['Transmission_Manual']
        if(Transmission_Manual=='Manual'):
            Transmission_Automatic=0
            Transmission_Manual=1
        else:
            Transmission_Automatic=1
            Transmission_Manual=0

        Owner_FirstOwner=request.form['Owner_First Owner']
        if(Owner_FirstOwner=='first'):
               Owner_FirstOwner=1
               Owner_FourthAboveOwner=0
               Owner_SecondOwner=0
               Owner_TestDriveCar=0
               Owner_ThirdOwner=0
        elif(Owner_FirstOwner=='second'):
               Owner_FirstOwner=0
               Owner_FourthAboveOwner=0
               Owner_SecondOwner=1
               Owner_TestDriveCar=0
               Owner_ThirdOwner=0
        elif(Owner_FirstOwner=='third'):
               Owner_FirstOwner=0
               Owner_FourthAboveOwner=0
               Owner_SecondOwner=0
               Owner_TestDriveCar=0
               Owner_ThirdOwner=1
        elif(Owner_FirstOwner=='forth'):
               Owner_FirstOwner=0
               Owner_FourthAboveOwner=1
               Owner_SecondOwner=0
               Owner_TestDriveCar=0
               Owner_ThirdOwner=0
        else:
               Owner_FirstOwner=0
               Owner_FourthAboveOwner=0
               Owner_SecondOwner=0
               Owner_TestDriveCar=1
               Owner_ThirdOwner=0

        Seat_high=request.form['Seat_high']
        if(Seat_high=='high'):
            Seat_high=1
            Seat_middle=0
            Seat_normal=0
        elif(Seat_high=='medium'):
            Seat_high=0
            Seat_middle=1
            Seat_normal=0
        else:
            Seat_high=0
            Seat_middle=0
            Seat_normal=1
        prediction=model.predict([[year,km_driven,AvgMileage,EngineCC,MaxPower,Fuel_CNG,Fuel_Diesel,Fuel_LPG,Fuel_Petrol,
                                    SellerType_Dealer,SellerType_Individual,SellerType_TrustmarkDealer,
                                    Transmission_Automatic,Transmission_Manual,Owner_FirstOwner,
                                    Owner_FourthAboveOwner,Owner_SecondOwner,
                                    Owner_TestDriveCar,Owner_ThirdOwner,Seat_high,Seat_middle,
                                    Seat_normal]])
        output=round(prediction[0],2)
        if output<0:
            return render_template('index.html',prediction_texts="Sorry there are no cars with the required features")
        else:
            return render_template('index.html',prediction_text=" Selling price of car is : {}".format(output))
    else:
        return render_template('index.html')

if __name__=="__main__":
    app.run(debug=True)

